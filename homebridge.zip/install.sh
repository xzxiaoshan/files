#!/bin/bash
npm install -gs homebridge-harmonyhub
npm install -gs homebridge-netatmo
npm install -gs homebridge-nukiio
npm install -gs homebridge-synology
npm install -gs homebridge-homeassistant